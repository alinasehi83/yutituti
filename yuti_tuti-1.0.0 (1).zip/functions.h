#ifndef YUTI_TUTI_FUNCTIONS_H
#define YUTI_TUTI_FUNCTIONS_H

#include "defines.h"

char *signup(
        struct user_list **,
        cmd_struct *
);

char *login(
        struct user_list *,
        cmd_struct *
);

char *find_user(
        struct user_list *,
        cmd_struct *
);

void info(
        struct user_list *,
        char *
);

void post(
        struct user_list *,
        char *,
        char *
);

char *like(
        struct user_list *,
        cmd_struct *
);

char *delete(
        struct user_list *,
        char *,
        cmd_struct *
);

#endif
