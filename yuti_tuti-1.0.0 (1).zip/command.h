#ifndef YUTI_TUTI_COMMAND_H
#define YUTI_TUTI_COMMAND_H

#include "defines.h"

void get_command(cmd_struct *, char **, char *);

#endif
