#ifndef YUTI_TUTI_DEFINES_H
#define YUTI_TUTI_DEFINES_H

#define cmd_struct struct command
#define post_struct struct post
#define user_struct struct user

struct command {
    char *command;
    char **arguments;
};

struct post {
    char *user;
    unsigned post_id;
    unsigned likes;
    char *post_content;
};

struct post_list {
    post_struct *post;
    struct post_list *next;
};

struct user {
    char *username;
    char *password;
    struct post_list *posts;
};

struct user_list {
    user_struct *user;
    struct user_list *next;
};

#define MAX_COMMAND_ARGUMENTS 2
#define MAX_COMMAND_ARGUMENTS_LENGTH 64
#define BASE_USERS_MEMORY_ALLOCATION_SIZE 64
#define BASE_USER_POSTS_MEMORY_ALLOCATION_SIZE 128

#endif
