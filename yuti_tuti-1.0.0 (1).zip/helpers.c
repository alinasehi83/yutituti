#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "helpers.h"


void initial_command_struct(cmd_struct **command_struct) {

    *command_struct = (cmd_struct *) malloc(MAX_COMMAND_ARGUMENTS * sizeof(cmd_struct));

    (*command_struct)->command = malloc(MAX_COMMAND_ARGUMENTS_LENGTH * sizeof(char));

    (*command_struct)->arguments = malloc(MAX_COMMAND_ARGUMENTS * sizeof(char *));
    for (int i = 0; i < MAX_COMMAND_ARGUMENTS; i++) {
        (*command_struct)->arguments[i] = NULL;
        (*command_struct)->arguments[i] = malloc(MAX_COMMAND_ARGUMENTS_LENGTH * sizeof(char));
    }
}

void destruct_command_struct(cmd_struct *command_struct) {
    free(command_struct->command);

    for (int i = 0; i < MAX_COMMAND_ARGUMENTS; i++)
        free(command_struct->arguments[i]);
    free(command_struct->arguments);
}


void initial_users_list(struct user_list **users) {
    (*users) = (struct user_list *) malloc(sizeof(struct user_list));
    if ((*users) == NULL) {
        printf("[!] Can not allocate memory for users list.\n");
        exit(1);
    }
    (*users)->user = NULL;
    (*users)->next = NULL;
}

void add_user(struct user_list *users, user_struct *user) {
    struct user_list *ptr = NULL, *next_node = NULL;
    next_node = (struct user_list *) malloc(sizeof(struct user_list));
    next_node->user = NULL;
    next_node->next = NULL;
    if (users->next == NULL) {
        users->user = user;
        users->next = next_node;
    } else {
        ptr = users;
        while (ptr->next != NULL)
            ptr = ptr->next;

        ptr->user = user;
        ptr->next = next_node;
    }
}

void destruct_users(struct user_list *users) {
    struct user_list *user_ptr = NULL, *user_ptr_tmp = NULL;
    struct post_list *post_ptr = NULL, *post_ptr_tmp;
    user_ptr = users;
    while (user_ptr->next != NULL) {
        free(user_ptr->user->username);
        free(user_ptr->user->password);

        post_ptr = user_ptr->user->posts;
        while (post_ptr->next != NULL) {
            free(post_ptr->post->post_content);
            free(post_ptr->post->user);
            free(post_ptr->post);
            post_ptr = post_ptr->next;
        }
        post_ptr = user_ptr->user->posts;
        while (post_ptr != NULL) {
            post_ptr_tmp = post_ptr;
            post_ptr = post_ptr->next;
            post_ptr_tmp->next = NULL;
            free(post_ptr_tmp);
        }

        free(user_ptr->user);
        user_ptr->user = NULL;

        user_ptr = user_ptr->next;
    }

    user_ptr = users;
    while (user_ptr != NULL) {
        user_ptr_tmp = user_ptr;
        user_ptr = user_ptr->next;
        user_ptr_tmp->next = NULL;
        free(user_ptr_tmp);
    }
}

void initial_posts_list(struct post_list **posts) {
    (*posts) = (struct post_list *) malloc(sizeof(struct post_list));
    if ((*posts) == NULL) {
        printf("[!] Can not allocate memory for posts list.\n");
        exit(1);
    }
    (*posts)->post = NULL;
    (*posts)->next = NULL;
}

void add_post(struct post_list *posts, post_struct *post) {
    struct post_list *ptr;
    struct post_list *node = NULL;
    node = (struct post_list *) malloc(sizeof(struct post_list));
    node->post = NULL;
    node->next = NULL;
    if (posts->next == NULL) {
        posts->post = post;
        posts->next = node;
    } else {
        ptr = posts;
        while (ptr->next != NULL)
            ptr = ptr->next;

        ptr->post = post;
        ptr->next = node;
    }
}

int delete_post(struct post_list **posts, unsigned post_index) {
    struct post_list *ptr, *tmp;

    if (post_index < 1)
        return -1;

    ptr = (*posts);
    if ((*posts)->post == NULL)
        return -1;

    if (ptr->post->post_id == post_index) {
        tmp = (*posts);
        (*posts) = (*posts)->next;

        if ((*posts) == NULL) {
            struct post_list *node = NULL;
            node = (struct post_list *) malloc(sizeof(struct post_list));
            node->post = NULL;
            node->next = NULL;
            (*posts) = node;
        }

        free(tmp->post->post_content);
        free(tmp->post->user);
        free(tmp->post);
        free(tmp);
        tmp = NULL;
    } else {
        struct post_list *p1, *p2;

        if ((*posts)->next->post == NULL)
            return -1;

        p1 = (*posts);
        p2 = p1->next;

        while (p2->post->post_id != post_index && p2->next->post != NULL) {
            p1 = p1->next;
            p2 = p2->next;
        }

        if (p2->post == NULL)
            return -1;

        if (p2->post->post_id == post_index) {
            p1->next = p2->next;
            free(p2->post->post_content);
            free(p2->post->user);
            free(p2->post);
            free(p2);
            p2 = NULL;
        } else return -1;
    }

    return 0;
}

void save_data(struct user_list *users) {
    struct user_list *user_ptr = NULL;
    struct post_list *post_ptr = NULL;

    FILE *accounts_fp = NULL;
    FILE *posts_fp = NULL;

    char *accounts_buffer = NULL;
    char *posts_buffer = NULL;

    accounts_fp = fopen("./accounts.txt", "w");
    posts_fp = fopen("./posts.txt", "w");

    user_ptr = users;
    while (user_ptr->next != NULL) {
        char *username = user_ptr->user->username;
        char *password = user_ptr->user->password;

        int posts_count = 0;
        post_ptr = user_ptr->user->posts;
        while (post_ptr->next) {

            size_t posts_buffer_size = (strlen(post_ptr->post->post_content) + strlen(username) + 32) * sizeof(char);
            if (posts_buffer == NULL) {
                posts_buffer = (char *) malloc(posts_buffer_size);
                memset(posts_buffer, '\0', posts_buffer_size);
            } else {
                char *tmp = NULL;
                tmp = realloc(posts_buffer, strlen(posts_buffer) + posts_buffer_size);
                if (tmp == NULL) {
                    printf("[!] could not allocate memory for posts_buffer.\n");
                    exit(1);
                }

                posts_buffer = tmp;
            }

            char tmp[posts_buffer_size];
            sprintf(tmp, "%s %s %u\n", post_ptr->post->post_content, username, post_ptr->post->likes);
            strcat(posts_buffer, tmp);

            posts_count++;
            post_ptr = post_ptr->next;
        }

        size_t accounts_buffer_size = (strlen(username) + strlen(password) + 32) * sizeof(char);

        if (accounts_buffer == NULL) {
            accounts_buffer = (char *) malloc(accounts_buffer_size);
            memset(accounts_buffer, '\0', accounts_buffer_size);
        } else {
            char *tmp = NULL;
            tmp = realloc(accounts_buffer, strlen(accounts_buffer) + accounts_buffer_size);
            if (tmp == NULL) {
                printf("[!] could not allocate memory for accounts_buffer.\n");
                exit(1);
            }

            accounts_buffer = tmp;
        }

        char tmp[accounts_buffer_size];
        sprintf(tmp, "%s %s %u\n", username, password, posts_count);
        strcat(accounts_buffer, tmp);

        user_ptr = user_ptr->next;
    }

    fprintf(accounts_fp, "%s", accounts_buffer);
    fprintf(posts_fp, "%s", (posts_buffer == NULL ? "" : posts_buffer));

    fclose(accounts_fp);
    fclose(posts_fp);
    accounts_fp = NULL;
    posts_fp = NULL;

    free(accounts_buffer);
    free(posts_buffer);
}
