#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defines.h"
#include "command.h"
#include "functions.h"
#include "helpers.h"

int main() {
    printf("Yuti Tuti (version 1.0.0)\n");

    int logged_in = 0;
    char *logged_in_username = NULL;

    struct user_list *users = NULL;
    initial_users_list(&users);


    while (1) {
        char *full_cmd_input = NULL;
        cmd_struct *cmd = NULL;
        initial_command_struct(&cmd);

        if (cmd == NULL) {
            printf("Could not allocate memory for command array.\n");
            exit(1);
        }

        get_command(cmd, &full_cmd_input, (logged_in ? logged_in_username : NULL));

        if (strcmp(cmd->command, "signup") == 0) {
            if (logged_in != 0) {
                printf("[!] You are logged in, so you should logout before trying to signup.\n");
                destruct_command_struct(cmd);
                free(cmd);
                continue;
            }

            char *signup_error_message = NULL;
            signup_error_message = signup(&users, cmd);
            if (signup_error_message != NULL) {
                printf("%s", signup_error_message);
                free(signup_error_message);
            } else {
                printf("[i] account was created successfully.\n");
            }
        } else if (strcmp(cmd->command, "login") == 0) {
            if (logged_in != 0) {
                printf("[!] You are logged in, so you should logout before trying to login.\n");
                destruct_command_struct(cmd);
                free(cmd);
                free(full_cmd_input);
                continue;
            }

            char *login_error_message = NULL;
            login_error_message = login(users, cmd);

            if (login_error_message != NULL) {
                printf("%s", login_error_message);
            } else {
                logged_in = 1;
                logged_in_username = malloc(1 + strlen(cmd->arguments[0]) * sizeof(char));
                strcpy(logged_in_username, cmd->arguments[0]);
                logged_in_username[strlen(logged_in_username)] = '\0';
            }
            free(login_error_message);
        } else if (strcmp(cmd->command, "post") == 0) {
            if (logged_in != 1) {
                printf("[!] You are not logged in, so you should login before trying to get you account info.\n");
                destruct_command_struct(cmd);
                free(cmd);
                free(full_cmd_input);
                continue;
            }

            char *post_content = NULL;
            int post_content_start_index = 0;
            int err = sscanf(full_cmd_input, "%*s %n\n", &post_content_start_index);

            if (err == -1 || strlen(cmd->arguments[0]) == 0) {
                printf("[!] could not read post content.\n");
                free(post_content);
            } else {
                post_content = full_cmd_input + post_content_start_index;
                if (post_content[strlen(post_content) - 1] == '\n')
                    post_content[strlen(post_content) - 1] = '\0';
                post(users, logged_in_username, post_content);
            }
        } else if (strcmp(cmd->command, "like") == 0) {
            if (logged_in != 1) {
                printf("[!] You are not logged in, so you should login before trying to like a post.\n");
                destruct_command_struct(cmd);
                free(cmd);
                free(full_cmd_input);
                continue;
            }

            char *like_error_message = NULL;
            like_error_message = like(users, cmd);
            if (like_error_message != NULL) {
                printf("%s", like_error_message);
                free(like_error_message);
                like_error_message = NULL;
            } else {
                printf("[i] Post liked.\n");
            }
        } else if (strcmp(cmd->command, "logout") == 0) {
            if (logged_in == 1) {
                logged_in = 0;
                free(logged_in_username);
                logged_in_username = NULL;
                printf("You logged out, we hope to see you soon :)\n");
            } else {
                printf("[!] You are not logged in, so you should login before trying to logout.\n");
            }
        } else if (strcmp(cmd->command, "delete") == 0) {
            if (logged_in != 1) {
                printf("[!] You are not logged in, so you should login before trying to delete your post.\n");
                destruct_command_struct(cmd);
                free(cmd);
                free(full_cmd_input);
                continue;
            }
            char *delete_error_message = NULL;
            delete_error_message = delete(users, logged_in_username, cmd);

            if (delete_error_message != NULL) {
                printf("%s", delete_error_message);
                free(delete_error_message);
                delete_error_message = NULL;
            } else {
                printf("[i] Post deleted.\n");
            }
        } else if (strcmp(cmd->command, "info") == 0) {
            if (logged_in != 1) {
                printf("[!] You are not logged in, so you should login before trying to get you account info.\n");
                destruct_command_struct(cmd);
                free(cmd);
                free(full_cmd_input);
                continue;
            }
            info(users, logged_in_username);
        } else if (strcmp(cmd->command, "find_user") == 0) {
            char *find_user_error_message = NULL;
            find_user_error_message = find_user(users, cmd);
            if (find_user_error_message != NULL) {
                printf("%s", find_user_error_message);
            }
            free(find_user_error_message);
        } else if (strcmp(cmd->command, "quit") == 0) {
            destruct_command_struct(cmd);
            free(cmd);
            free(full_cmd_input);
            break;
        } else {
            printf("[!] Command \"%s\" not recognized.\n", cmd->command);
        }

        destruct_command_struct(cmd);
        free(full_cmd_input);
        free(cmd);
    }
    save_data(users);

    destruct_users(users);
    free(logged_in_username);

    return 0;
}
