#ifndef YUTI_TUTI_HELPERS_H
#define YUTI_TUTI_HELPERS_H

#include <stdlib.h>
#include <stdio.h>
#include "defines.h"

void initial_command_struct(cmd_struct **command_struct);

void destruct_command_struct(cmd_struct *command_struct);

void initial_users_list(struct user_list **users);

void add_user(struct user_list *users, user_struct *user);

void destruct_users(struct user_list *users_struct);

void initial_posts_list(struct post_list **posts);

void add_post(struct post_list *posts, post_struct *post);

int delete_post(struct post_list **posts, unsigned post_index);

void save_data(struct user_list *users);

#endif
