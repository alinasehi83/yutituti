#include <stdlib.h>
#include <string.h>
#include "functions.h"
#include "defines.h"
#include "helpers.h"

char *signup(
        struct user_list **users,
        cmd_struct *cmd
) {

    char *error_message = NULL;
    error_message = (char *) malloc(128 * sizeof(char));

    char *username = cmd->arguments[0];
    char *password = cmd->arguments[1];

    if (strlen(username) == 0 || strlen(password) == 0) {
        strcpy(error_message, "[!] username and password are required.\n");
        return error_message;
    }

    struct user_list *ptr = NULL;
    ptr = (*users);
    while (ptr->next != NULL) {
        if (ptr->user == NULL)
            break;

        if (strcmp(ptr->user->username, username) == 0) {
            strcpy(error_message, "[!] username is used by another user.\n");
            return error_message;
        }

        ptr = ptr->next;
    }

    user_struct *user = NULL;
    user = (user_struct *) malloc(sizeof(user_struct));

    user->username = malloc(MAX_COMMAND_ARGUMENTS_LENGTH * sizeof(char));
    user->password = malloc(MAX_COMMAND_ARGUMENTS_LENGTH * sizeof(char));

    strcpy(user->username, username);
    strcpy(user->password, password);
    initial_posts_list(&(user->posts));

    add_user(*users, user);

    free(error_message);
    return NULL;
}

char *login(
        struct user_list *users,
        cmd_struct *cmd
) {
    char *error_message = NULL;
    error_message = (char *) malloc(128 * sizeof(char));

    char *username = cmd->arguments[0];
    char *password = cmd->arguments[1];

    if (strlen(username) == 0 || strlen(password) == 0) {
        strcpy(error_message, "[!] username and password are required.\n");
        return error_message;
    }


    struct user_list *ptr = NULL;
    ptr = users;
    while (ptr->next != NULL) {
        if (ptr->user == NULL)
            break;

        if (strcmp(ptr->user->username, username) == 0) {
            if (strcmp(ptr->user->password, password) == 0) {
                printf("Welcome to Yuti Tuti, %s.\n", ptr->user->username);
                free(error_message);
                return NULL;
            } else {
                strcpy(error_message, "[!] password is not correct.\n");
                return error_message;
            }
        }

        ptr = ptr->next;
    }

    strcpy(error_message, "[!] username does not exist.\n");
    return error_message;
}

char *find_user(
        struct user_list *users,
        cmd_struct *cmd
) {
    char *error_message = NULL;
    error_message = (char *) malloc(128 * sizeof(char));

    char *username = cmd->arguments[0];

    if (strlen(username) == 0) {
        strcpy(error_message, "[!] username is required.\n");
        return error_message;
    }

    struct user_list *user_ptr = NULL;
    user_ptr = users;
    while (user_ptr->next != NULL) {
        if (user_ptr->user == NULL)
            break;

        if (strcmp(user_ptr->user->username, username) == 0) {
            printf("[i] found user : %s\n", user_ptr->user->username);
            printf("[i] %s's posts : \n", user_ptr->user->username);
            struct post_list *ptr;
            ptr = user_ptr->user->posts;
            while (ptr->next != NULL) {
                printf("{\n");
                printf("\tuser: %s\n", ptr->post->user);
                printf("\tpost_id: %u\n", ptr->post->post_id);
                printf("\tlikes: %u\n", ptr->post->likes);
                printf("\tpost: %s\n", ptr->post->post_content);
                printf("}\n\n");
                ptr = ptr->next;
            }

            free(error_message);
            return NULL;
        }

        user_ptr = user_ptr->next;
    }

    strcpy(error_message, "[!] username does not exist.\n");
    return error_message;
}

void info(
        struct user_list *users,
        char *username
) {
    struct user_list *user_ptr = NULL;
    user_ptr = users;
    while (user_ptr->next != NULL) {
        if (user_ptr->user == NULL)
            break;

        if (strcmp(user_ptr->user->username, username) == 0) {
            printf("{\n");
            printf("\tusername: %s\n", user_ptr->user->username);
            printf("\tpassword: %s\n", user_ptr->user->password);
            printf("\tposts: {\n");
            struct post_list *ptr;
            ptr = user_ptr->user->posts;

            while (ptr->next != NULL) {
                if (ptr->post == NULL) {
                    ptr = ptr->next;
                    continue;
                }
                printf("\t\t{\n");
                printf("\t\t\tpost_id: %u\n", ptr->post->post_id);
                printf("\t\t\tlikes: %u\n", ptr->post->likes);
                printf("\t\t\tpost: %s\n", ptr->post->post_content);
                printf("\t\t}\n");
                ptr = ptr->next;
            }
            printf("\t}\n");
            printf("{\n");
        }

        user_ptr = user_ptr->next;
    }
}


void post(
        struct user_list *users,
        char *username,
        char *post_content
) {

    struct user_list *user_ptr = NULL;
    user_ptr = users;
    while (user_ptr->next != NULL) {
        if (user_ptr->user == NULL)
            break;

        if (strcmp(user_ptr->user->username, username) == 0) {

            struct post_list *ptr;
            ptr = user_ptr->user->posts;

            unsigned last_id = 0;
            while (ptr->next != NULL) {
                last_id = ptr->post->post_id;
                ptr = ptr->next;
            }

            post_struct *post = NULL;
            post = (post_struct *) malloc(sizeof(post_struct));

            post->user = malloc((strlen(user_ptr->user->username) + 1) * sizeof(char));
            post->post_content = malloc((strlen(post_content) + 1) * sizeof(char));

            post->post_id = last_id + 1;
            post->likes = 0;
            strcpy(post->user, user_ptr->user->username);
            strcpy(post->post_content, post_content);

            add_post(user_ptr->user->posts, post);
        }

        user_ptr = user_ptr->next;
    }
}

char *like(
        struct user_list *users,
        cmd_struct *cmd
) {
    char *error_message = NULL;
    error_message = malloc(128 * sizeof(char));

    char *username = NULL;
    int post_id = 0;

    username = malloc(MAX_COMMAND_ARGUMENTS_LENGTH * sizeof(char));
    strcpy(username, cmd->arguments[0]);

    int err = sscanf(cmd->arguments[1], "%d", &post_id);
    if (err != 1) {
        strcpy(error_message, "[!] could not read post ID from input.\n");
        return error_message;
    }

    struct user_list *user_ptr = NULL;
    user_ptr = users;
    while (user_ptr->next != NULL) {
        if (user_ptr->user == NULL) {
            strcpy(error_message, "[!] post ID is not valid.\n");
            return error_message;
        }

        if (strcmp(user_ptr->user->username, username) == 0) {
            struct post_list *ptr;
            ptr = user_ptr->user->posts;

            int count = 1;
            while (ptr->next != NULL && post_id != count) {
                ptr = ptr->next;
                count++;
            }

            if (post_id != count || ptr->post == NULL) {
                strcpy(error_message, "[!] post ID is not valid.\n");
                return error_message;
            }

            ptr->post->likes++;
        }

        user_ptr = user_ptr->next;
    }

    free(error_message);
    error_message = NULL;
    return NULL;
}

char *delete(
        struct user_list *users,
        char *username,
        cmd_struct *cmd
) {
    char *error_message = NULL;
    error_message = (char *) malloc(128 * sizeof(char));

    unsigned post_id = 0;
    int err = sscanf(cmd->arguments[0], "%d", &post_id);
    if (err != 1) {
        strcpy(error_message, "[!] could not read post ID from input.\n");
        return error_message;
    }

    struct user_list *user_ptr = NULL;
    user_ptr = users;
    while (user_ptr->next != NULL) {
        if (user_ptr->user == NULL) {
            strcpy(error_message, "[!] could not delete post.\n");
            return error_message;
        }

        if (strcmp(username, user_ptr->user->username) == 0) {
            int delete_result = delete_post(&user_ptr->user->posts, post_id);

            if (delete_result == -1) {
                strcpy(error_message, "[!] could not delete post.\n");
                return error_message;
            }
        }
    }

    free(error_message);
    return NULL;
}