#include "command.h"
#include "defines.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void get_command(cmd_struct *command_struct, char **cmd_tmp, char *logged_in_username) {
    char *buffer;
    char format_string[32];
    size_t buffer_allocated_size = 0;
    ssize_t buffer_length = 0;


    while (1) {
        printf("%s$ ", (logged_in_username == NULL ? "" : logged_in_username));

        buffer = (char *) NULL;
        buffer_length = getline(&buffer, &buffer_allocated_size, stdin);
        *cmd_tmp = (char *) malloc((strlen(buffer) + 1) * sizeof(char *));
        strcpy(*cmd_tmp, buffer);
        buffer_length--; // for \n at the end of line
        sprintf(format_string, "%%%ds %%%ds %%%ds\n", MAX_COMMAND_ARGUMENTS_LENGTH, MAX_COMMAND_ARGUMENTS_LENGTH,
                MAX_COMMAND_ARGUMENTS_LENGTH);
        sscanf(buffer, format_string, command_struct->command, command_struct->arguments[0],
               command_struct->arguments[1]);

        if (buffer_length == 0)
            continue;
        break;
    }

    free(buffer);
}
